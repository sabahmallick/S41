# SpikingModel
Simple spiking cell for demonstration purposes.

## How to run
1. Compile (mknrndll in Windows, nrnivmodl in Unix)
2. Run main.hoc
3. Run analyze.py to plot figure from the generated text file data.
